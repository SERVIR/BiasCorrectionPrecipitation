Sample data:
Location: Nyando basin in Kenya
Station used for CHIRPS Adjustment: KERICHO @ 0.367 S, 35.35 E
SPP to be bias-corrected: PERSIANN (downloaded from http://chrsdata.eng.uci.edu/)
Year: 2015
